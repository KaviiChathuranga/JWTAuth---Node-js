const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const fs = require('fs');
const tokenHandler = require('../app/Helpers/tokenHandler.js');
const customerController = require('../app/Http/Controllers/customerController');

router.get('/readme', (req, res) => {
    res.json({"message": "This is open to the world!"})
});
router.post('/customer/create', (req, res) => {
    const user = tokenHandler.getCurrentUser(req);
    return customerController.createCustomer(req, res);
});
router.get('/jwt', (req, res) => {
    const user = {
        id: '1450632410296',
        name: 'kavindu chathuranga'
    };
    const token = tokenHandler.setToken(user);
    res.send(token);
});

router.get('/secret', isAuthenticated, (req, res) => {
    console.log(tokenHandler.getCurrentUser(req));
    res.json({"message": "THIS IS SUPER SECRET, DO NOT SHARE!"});
});

function isAuthenticated(req, res, next) {
    if (typeof req.headers.authorization !== "undefined") {
        const token = req.headers.authorization.split(" ")[1];
        const privateKey = fs.readFileSync('./private.pem', 'utf8');

        jwt.verify(token, privateKey, {algorithm: "HS256"}, (err, user) => {
            if (err) {
                res.status(500).json({error: "Not Authorized"});
                throw new Error("Not Authorized");
            }
            return next();
        });
    } else {
        res.status(500).json({error: "Not Authorized"});
        throw new Error("Not Authorized");
    }

}

module.exports = router;
