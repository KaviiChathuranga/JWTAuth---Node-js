const fs = require('fs');
const jwt = require('jsonwebtoken');

class TokenHandler {

    static verifyToken = (jwtToken) => {
        try {
            return jwt.verify(jwtToken, fs.readFileSync('private.pem', 'utf8'));
        } catch (e) {
            console.error('e:', e);
            return null;
        }
    };

    static getCurrentUser(req) {
        let authHeader = req.header('Authorization');
        let sessionID = authHeader.split(' ')[1];
        let userData = this.verifyToken(sessionID);
        return userData.body;
    };

    static setToken(user) {
        const privateKey = fs.readFileSync('private.pem', 'utf8');
        const token = jwt.sign({"body": user}, privateKey, {algorithm: 'HS256'});
        return token;
    }
}

module.exports = TokenHandler;