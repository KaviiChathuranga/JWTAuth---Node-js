exports.createCustomer = async function (name, email) {
   return name;
}


// module.exports = CustomerService;