class CustomerRepository {
    
}